
    const issues = [
      {
        id: 1, status: 'New', owner: 'Ravan', effort: 5,
        created: new Date('2018-08-15'), due: undefined,
        title: 'Error in console when clicking Add'
      },
      {
        id: 2, status: 'Assigned', owner: 'Eddie', effort: 15,
        created: new Date('2018-08-16'), due: new Date('2018-08-30'),
        title: 'Missing bottom border on panel'
      },
      {
        id: 3, status: 'New', owner: 'Elizabeth', effort: 9,
        created: new Date('2019-08-16'), due: new Date('2019-08-30'),
        title: 'Style missing bold component'
      },
      {
        id: 4, status: 'New', owner: 'Kevin', effort: 5,
        created: new Date('2017-02-5'), due: undefined,
        title: 'Error in console when clicking Add'
      },
      {
        id: 5, status: 'New', owner: 'Jason', effort: 15,
        created: new Date('2020-03-18'), due: new Date('2018-08-30'),
        title: 'Logic error in console'
      },
      {
        id: 6, status: 'New', owner: 'Sean', effort: 9,
        created: new Date('2016-05-02'), due: new Date('2019-08-30'),
        title: 'Style missing bold component'
      },
      {
        id: 7, status: 'New', owner: 'Kentrell', effort: 5,
        created: new Date('2014-10-13'), due: undefined,
        title: 'Error in console when clicking Add'
      },
      {
        id: 8, status: 'Assigned', owner: 'Alicia', effort: 15,
        created: new Date('2016-09-8'), due: new Date('2018-08-30'),
        title: 'Missing expected brackets'
      },
      {
        id: 9, status: 'Assigned', owner: 'Maria', effort: 9,
        created: new Date('2013-11-14'), due: new Date('2019-08-30'),
        title: 'Logic error in console'
      },
      {
        id: 10, status: 'New', owner: 'Grace', effort: 9,
        created: new Date('2019-06-26'), due: new Date('2019-08-30'),
        title: 'Runtime error in console'
      }
    ];

class IssueFilter extends React.Component {
  render () {
    return (
      <div>This is a placeholder for a the issue filter.</div>
    );
  }
}

class IssueRow extends React.Component {
  render() {
    const issue = this.props.issue;
    return (
      <tr>
      <td>{issue.id}</td>
      <td>{issue.status}</td>
      <td>{issue.owner}</td>
      <td>{issue.created.toDateString()}</td>
      <td>{issue.effort}</td>
      <td>{issue.due ? issue.due.toDateString() : ''}</td>
      <td>{issue.title}</td>
      </tr>
    )
  }
}

class IssueTable extends React.Component {
  render () {
    const issueRows = issues.map(issue =>
      <IssueRow  issue={issue}/>
    );

    return (
      <table className = "bordered-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Status</th>
            <th>Owner</th>
            <th>Created</th>
            <th>Effort</th>
            <th>Due Date</th>
            <th>Title</th>
          </tr>
        </thead>
        <tbody>
          {issueRows}
        </tbody>
      </table>
    );
  }
}

class IssueAdd extends React.Component {
  render () {
    return (
      <div>This is a placeholder for a form to add an issue</div>
    );
  }
}

class IssueList extends React.Component {
  render() {
    return (
      <React.Fragment>
        <h1>Issue Tracker</h1>
        <IssueFilter />
        <hr />
        <IssueTable />
        <hr />
        <IssueAdd />
      </React.Fragment>
    );
  }
}

    const element = <IssueList />;

    ReactDOM.render(element, document.getElementById('contents'));
