

/* esLint "react/prefer-stateless-function": "off" */

import React from 'react';

// eslint-disable-next-line react/prefer-stateless-function
export default class IssueFilter extends React.Component {
  render() {
    return (
      <div>This is a placeholder for the issue filter</div>
    );
  }
}
